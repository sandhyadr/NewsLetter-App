import * as React from 'react';
import { View, Text, TouchableOpacity,StyleSheet } from 'react-native';

export default class Horoscope extends React.Component{
  render(){
    return(
        <Text>Baccha</Text>
    );
  }
}