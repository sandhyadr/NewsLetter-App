import * as React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import AppHeader from '../components/AppHeader';
import db from 'firebase';

export default class HomeScreen extends React.Component {
  goToNews = () => {
    this.props.navigation.navigate('News');
  };
  goToJoke = () => {
    this.props.navigation.navigate('Joke');
  };
  goToHoro = () => {
    this.props.navigation.navigate('Horo');
  };
  goToWeatherScreen = () => {
    this.props.navigation.navigate('Weather');
  };

  dislikePressed() {
    var dislike = db.ref('isDislikePressed');
        dislike.update({
      isDislikePressed: 1,
    });
  }

  likePressed() {
    var like = db.ref('isLikePressed');
        like.update({
      isLikePressed: 1,
    });
  }

  render() {
    return (
      <View>
        <AppHeader />
        <View style={{ backgroundColor: 'gray' }}>
          <TouchableOpacity
            style={[styles.button, { backgroundColor: 'red' }]}
            onPress={this.goToNews}>
            <Text style={styles.buttonText}>Latest News</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.button, { backgroundColor: 'green' }]}
            onPress={this.goToJoke}>
            <Text style={styles.buttonText}>Hear a Joke</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.button, { backgroundColor: 'blue' }]}
            onPress={this.goToHoro}>
            <Text style={styles.buttonText}>See my HoroScope</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.button, { backgroundColor: 'yellow' }]}
            onPress={this.goToWeatherScreen}>
            <Text style={styles.buttonText}>Weather Forecast</Text>
          </TouchableOpacity>

        <View>
          <TouchableOpacity onPress={this.likePressed}>
            <Image
              style={{ width: 50, height: 50, marginLeft: 100 }}
              source={require('../assets/thumbsup.png')}
            />
          </TouchableOpacity>

          <TouchableOpacity onPress={this.likePressed}>
            <Image
              style={{ width: 50, height: 50, marginLeft: 170 }}
              source={require('../assets/thumbsdown.png')}
            />
          </TouchableOpacity>
        </View>

        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  button: {
    justifyContent: 'center',
    alignSelf: 'center',
    borderWidth: 2,
    borderRadius: 15,
    marginTop: 50,
    width: 200,
    height: 50,
  },
  buttonText: {
    textAlign: 'center',
    color: 'white',
  },
});
