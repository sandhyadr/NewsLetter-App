import * as React from 'react';
import { View, Text, TouchableOpacity,StyleSheet } from 'react-native';

export default class News extends React.Component{
  render(){
    return(
        <Text>3 teams qualify for playoff ipl 2020</Text>
    );
  }
}