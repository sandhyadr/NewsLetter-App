import * as React from 'react';
import { View, Text, TouchableOpacity,StyleSheet } from 'react-native';

export default class Joke extends React.Component{
  render(){
    return(
       <View>
        <Text>HAHAHA</Text>
       </View> 
    );
  }
}