import firebase from 'firebase';

  var firebaseConfig = {
    apiKey: "AIzaSyCgjGrfZAoAsGHP5xlIYClIbo38HhB0UlQ",
    authDomain: "newsletter-f978a.firebaseapp.com",
    databaseURL: "https://newsletter-f978a.firebaseio.com",
    projectId: "newsletter-f978a",
    storageBucket: "newsletter-f978a.appspot.com",
    messagingSenderId: "157301843266",
    appId: "1:157301843266:web:f3766779bbdcd9cf83d4db"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

export default firebase.database() 