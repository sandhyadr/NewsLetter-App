import * as React from 'react';
import { View } from 'react-native';
import HomeScreen from './screens/HomeScreen';
import News from './screens/NEWS';
import Weather from './screens/WeatherScreen';
import JokeScreen from './screens/JokeScreen';
import Horo from './screens/HoroScope';
import { createAppContainer, createSwitchNavigator } from 'react-navigation';

export default class App extends React.Component {
  render() {
    return (
      <View>
        <AppContainer />
      </View>
    );
  }
}

var AppNavigator = createSwitchNavigator({
  Home: HomeScreen,
  News: News,
  Joke: JokeScreen,
  Horo: Horo,
  Weather: Weather
});

const AppContainer = createAppContainer(AppNavigator);